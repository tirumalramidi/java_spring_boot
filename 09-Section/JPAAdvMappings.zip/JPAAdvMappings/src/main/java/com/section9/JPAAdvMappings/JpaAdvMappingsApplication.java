package com.section9.JPAAdvMappings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaAdvMappingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaAdvMappingsApplication.class, args);
	}

}
