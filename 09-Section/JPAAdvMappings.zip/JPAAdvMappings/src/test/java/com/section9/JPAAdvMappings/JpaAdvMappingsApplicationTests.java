package com.section9.JPAAdvMappings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaAdvMappingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
