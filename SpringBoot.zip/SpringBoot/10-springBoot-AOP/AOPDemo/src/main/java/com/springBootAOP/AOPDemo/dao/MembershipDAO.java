package com.springBootAOP.AOPDemo.dao;

public interface MembershipDAO {

    void addSillyMember();

    void goToSleep();

}
