package com.springBootAOP.AOPDemo.service;

public interface TrafficFortuneService {

    String getFortune();

    String getFortune(boolean tripWire);
}
