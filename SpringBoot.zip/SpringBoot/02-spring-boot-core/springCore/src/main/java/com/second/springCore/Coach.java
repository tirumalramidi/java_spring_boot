package com.second.springCore;

public interface Coach {

    String getDailyWorkout();

}
