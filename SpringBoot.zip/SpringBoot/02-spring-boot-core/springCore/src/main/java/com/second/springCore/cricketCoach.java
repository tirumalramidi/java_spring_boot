package com.second.springCore;

import org.springframework.stereotype.Component;


@Component
public class cricketCoach implements Coach{


    @Override
    public String getDailyWorkout() {
        return "Practise daily:Cricket";
    }
}
