package com.section8.springSecurityMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
