package com.restCrudApi.demo.rest;

import com.restCrudApi.demo.entity.Student;
import jakarta.annotation.PostConstruct;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentRestController {

    private List<Student> theStudents;

    @PostConstruct
    public void loadData(){

        theStudents = new ArrayList<>();
        theStudents.add(new Student("Ravii","Reddy"));
        theStudents.add(new Student("surya","kumar"));
        theStudents.add(new Student("virat","kohli"));
        theStudents.add(new Student("rohit","sharma"));
        theStudents.add(new Student("ms","dhoni"));
    }


    @GetMapping("/students")
    public List<Student> getStudents(){


        return theStudents;
    }


    @GetMapping("/students/{studentid}")
    public Student getStudent(@PathVariable int studentid){

        if(studentid>=theStudents.size()){
            throw new studentNotFoundException("StudentNotFoundException with Id:"+studentid);
        }

         return theStudents.get(studentid);

    }




}
