package com.section3.crudDemo;

import com.section3.crudDemo.Entity.Student;
import com.section3.crudDemo.dao.studentDAO;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class CrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudDemoApplication.class, args);
	}


	@Bean
	public CommandLineRunner commandLineRunner(studentDAO studentDAO){

		return runner ->{
//			createStudent(studentDAO);
//			readStudent(studentDAO);
//			queryForStundents(studentDAO);
//			queryByLastName(studentDAO);
//			updateStudent(studentDAO);
//			removeStudent(studentDAO);
			deleteAllStudents(studentDAO);
		};
	}

	private void deleteAllStudents(studentDAO studentDAO) {

		int count = studentDAO.deleteAll();

		System.out.println("Numbers of columns deleted: "+count);

	}

	private void removeStudent(studentDAO studentDAO) {

		int id = 2;

		studentDAO.delete(id);

	}

	private void updateStudent(studentDAO studentDAO) {

		int id = 1;

		Student cStudent = studentDAO.findById(id);

		cStudent.setFirstName("ShriRam");

		studentDAO.update(cStudent);

	}

	private void queryByLastName(studentDAO studentDAO) {

		List<Student> list = studentDAO.findByLastName("Smiths");

		for(Student item:list){
			System.out.println(item.getFirstName());
		}

	}

	private void queryForStundents(studentDAO studentDAO) {


		List<Student> returnedList = studentDAO.findAll();

		for(Student item: returnedList){
			System.out.println(item.getFirstName()+" "+item.getLastName());
		}



	}

	private void readStudent(studentDAO studentDAO) {

		Student tempStudent = new Student("mavii","Smiths", "smithyi@gmail.com");

		studentDAO.save(tempStudent);

		Student rstudent = studentDAO.findById(tempStudent.getId());

		System.out.println(rstudent.getFirstName() + " " + rstudent.getLastName());


	}



	private void createStudent(studentDAO studentDAO) {

		Student tempStudent = new Student("Ravii","Suryavamshi", "suryavamshi@gmail.com");

		studentDAO.save(tempStudent);

		System.out.println("generated Id: "+ tempStudent.getId());

	}


}
