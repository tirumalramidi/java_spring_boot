package com.section3.crudDemo.dao;

import com.section3.crudDemo.Entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class studentDAOImpl implements studentDAO{

    private EntityManager entityManager;

    @Autowired
    public studentDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(Student theStudent) {
        entityManager.persist(theStudent);
    }

    @Override
    public Student findById(Integer id) {
        return entityManager.find(Student.class, id);
    }

    @Override
    public List<Student> findAll() {
        TypedQuery<Student> theQuery = entityManager.createQuery("From Student", Student.class);
        return theQuery.getResultList();
    }

    @Override
    public List<Student> findByLastName(String lastName) {
        TypedQuery<Student> theQuery = entityManager.createQuery("From Student where lastName=:placeholder", Student.class);

        theQuery.setParameter("placeholder", lastName);
        return theQuery.getResultList();
    }

    @Override
    @Transactional
    public void update(Student theStudent) {
        entityManager.merge(theStudent);
    }

    @Override
    @Transactional
    public void delete(Integer id) {

//        entityManager.createQuery("Delete From Student")
        Student s = entityManager.find(Student.class, id);
        entityManager.remove(s);
    }

    @Override
    @Transactional
    public int deleteAll() {
        int count = 0;

        count = entityManager.createQuery("Delete From Student").executeUpdate();
        return count;

    }
}
